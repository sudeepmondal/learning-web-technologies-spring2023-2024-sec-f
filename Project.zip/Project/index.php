<?php

    header('location: view/signin.php');

?>