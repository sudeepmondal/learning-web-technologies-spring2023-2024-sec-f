<?php

require_once('../model/userModel.php');
require_once('validations.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'];
    $name = $_POST['name'];
    $bio = $_POST['bio'];

    // Perform necessary backend logic (e.g., saving data to the database)
    $data = ['role'=> $role, 'name'=>$bio, 'bio'=> $bio];
    $status = createSP($data);

    // Assuming the operation is successful
    $response = array(
        "status" => "success",
        "data" => array(
            "role" => $role,
            "name" => $name,
            "bio" => $bio
        )
    );

    echo json_encode($response);
} else {
    // If the request method is not POST
    $response = array(
        "status" => "error",
        "message" => "Invalid request"
    );

    echo json_encode($response);
}
?>
